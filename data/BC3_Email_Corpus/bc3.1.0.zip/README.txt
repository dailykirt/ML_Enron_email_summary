The BC3 Corpus is published under the following license:
Creative Commons Attribution-Share Alike 3.0 Unported License
http://creativecommons.org/licenses/by-sa/3.0/

It is published by the University of British Columbia under the following webpage:
http://www.cs.ubc.ca/labs/lci/bc3.html

The corpus emails are in one xml file called corpus.xml and the annotations are in another xml file called annotations.xml.

If you have any questions or comments, please contact either:

Jan Ulrich - ulrichj@cs.ubc.ca
Gabriel Murray - gabrielm@cs.ubc.ca
Giuseppe Carenini - carenini@cs.ubc.ca